//variáveis do JOGADOR
let xJogador = 285; //posição horizontal(x) do jogador
let yJogador = 365; //posição vertical(y) do jogador
let dJogador = 30; //diâmetro do jogador

//funções referentes ao JOGADOR
function mostraJogador(){
   image(IJogador,xJogador,yJogador,dJogador,dJogador); //colocando a imagem do jogador, primeiro as coordenadas x e y, depois comprimento e altura da imagem 
}

//lembrando que a coordenada vertical(y), o positivo é de cima para baixo
function movimentoJogador(){ 
  if (keyIsDown(UP_ARROW)){
    yJogador -= 3
  }
  if (keyIsDown(DOWN_ARROW)){
    yJogador += 3
  }
  if (keyIsDown(RIGHT_ARROW)){
    xJogador += 3
  }
  if (keyIsDown(LEFT_ARROW)){
    xJogador -= 3
  }
}