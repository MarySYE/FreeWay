//VARIÁVEIS

let xCarros = [550,10,550,10,450,10] //posição horizontal(x) dos carros
let yCarros = [45,320,215,101,155,260] //posição vertical(y) dos carros
let vCarros = [2.5,3,4,5,1,3.4] //velocidade dos carros
let wCarros = 50; //wight dos carros
let hCarros = 40; //height dos carros

//FUNÇÕES

//para esta função foi criado um looping, gerando uma mesma linha de códigos diversas vezes, para parâmetros diferentes
function mostraCarros(){
    for(let i = 0; i < ICarros.length; i = i + 1){
  image(ICarros[i], xCarros[i], yCarros[i], wCarros, hCarros);
    }
}

//o .lenght é uma propriedade que retorna o número de parâmetros de uma array

//o mesmo pode ser feita nesta função, porém um dos carros se move na direção contrário, para isso será usado IF e ELSE, quando o número do carrinho na lista for par, será um direção, quando for ímpar será outra
function movimentoCarros(){
    for(let i = 0; i < ICarros.length; i = i + 1){
      if(i % 2 === 0){
        xCarros[i] -= vCarros[i];
        }    
      else {
        xCarros[i] += vCarros[i];      
       }
    }  
}

//assim como foi feita na função anterior, o mesmo será feito nesta, para os carrinhos pares da array uma condição e para os ímpares outra, para isto também será necessário criar outra função para verificar se os carros ultrapassaram a tela
function voltaCarro(){
    for(let i = 0; i < ICarros.length; i = i + 1){
        if(passouCarropar(xCarros[i])){
                xCarros[i] = 600;
        }
        if(passouCarroimp(xCarros[i])) {
                xCarros[i] = -50
        }
    }
}

//Eu ainda não sei como colocar a condição pares e ímpares, por isso escrevi os elementos das arrays por extenso
function passouCarropar(xCarro){
  if (ICarros[0] || ICarros[2]){
    return xCarro < - 50;
      }
}

function passouCarroimp(xCarro){
  if (ICarros[1])
  return xCarro > 600;
}
//Acredito que seria possível criar mais uma lista, com carros que iriam na direção oposta, o que também facilitaria o código, porém estou tentando seguir o que está sendo passado em aula, então por enquanto essa parte se mantém 