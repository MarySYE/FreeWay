//VARIÁVEL 

let hit = false

//FUNÇÕES

//com a librarie p5.collide2D, é possível montar a função de colisão sem escrever tudo por extenso, ela foi adicionada nos arquivos e agora pode ser usada aqui
function colisoes(){
  for (let i = 0; i < ICarros.length; i++){
    hit = collideRectCircle(xCarros[i], yCarros[i], wCarros, hCarros, xJogador, yJogador, 10)
  if(hit){
     colidiu();
     sColisao.play();
     }
  }
}

function colidiu(){
  yJogador = 365;
  xJogador = 285;
}

