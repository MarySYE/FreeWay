//IMAGENS

let IEstrada;
let ICarro1;
let ICarro2;
let ICarro3;
let ICarros;
let IJogador;

//SONS

let sTrilha;
let sPontos;
let sColisao;

//FUNÇÕES

function preload(){
  IEstrada = loadImage("imagens/estrada.png");
  IJogador = loadImage("imagens/ator-1.png");
  ICarro1 = loadImage("imagens/carro-1.png");
  ICarro2 = loadImage("imagens/carro-2.png");
  ICarro3 = loadImage("imagens/carro-3.png");
    ICarros = [ICarro1, ICarro2, ICarro3, ICarro1, ICarro2, ICarro3] //lista para cada imagem
  sTrilha = loadSound("sons/trilha.mp3");
  sPontos = loadSound("sons/pontos.wav");
  sColisao = loadSound("sons/colidiu.mp3");
}