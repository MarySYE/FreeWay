function setup() { 
  createCanvas(600, 400);
  sTrilha.loop();
}

function draw() {
  background(IEstrada);
  
  mostraJogador();
  mostraCarros();
  IPontos();
  MPontos();
  
  //funções do movimento
  
  movimentoJogador();
  voltaCarro();
  movimentoCarros();
  colisoes();
}
