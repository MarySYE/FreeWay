//VARIÁVEIS

let Pontos = 0;

//FUNÇÕES

function IPontos(){ //mostrando os pontos
  textSize(25);
  fill(color(255,240,60));
  text(Pontos, width/5, 27);
}

function MPontos(){ 
  if (yJogador < 0) {
    Pontos++; 
    colidiu();
    sPontos.play();
  }
}